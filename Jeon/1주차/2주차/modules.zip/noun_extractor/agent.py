from konlpy.tag import Mecab


class NounExtractAgent(object):
    def __init__(self):
        self.model = Mecab()

    def process(self, str_input):
        str_input = str_input.replace(" ", "")
        return list(set(self.model.nouns(str_input)))
