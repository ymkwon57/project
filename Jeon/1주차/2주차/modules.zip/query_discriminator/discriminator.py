import torch
from torch import nn
from torch.nn import functional as F


class Discriminator(nn.Module):
    def __init__(self,
                 input_dim,
                 num_filters,
                 ngram_filter_sizes,
                 word_embedding,
                 conv_layer_activation=F.relu,
                 highway_num_layers=2,
                 dropout=0.2,
                 cuda=True):

        super(Discriminator, self).__init__()

        self._input_dim = input_dim
        self._num_filters = num_filters
        self._conv_layer_activation = conv_layer_activation
        self._highway_num_layers = highway_num_layers
        self._ngram_filter_sizes = ngram_filter_sizes
        self._cuda = cuda

        self.embedding = word_embedding

        self.dropout = nn.Dropout(p=dropout)
        self.cnn_filters = [nn.Conv1d(in_channels=self._input_dim,
                                      out_channels=self._num_filters,
                                      kernel_size=ngram_size)
                           for ngram_size in self._ngram_filter_sizes]

        maxpool_output_dim = self._num_filters * len(self._ngram_filter_sizes)
        self.highway = Highway(maxpool_output_dim, num_layers=self._highway_num_layers)
        self.linear = nn.Linear(maxpool_output_dim, 1)

    def forward(self, inputs, function=F.sigmoid):
        embedding_vectors = self.embedding(inputs)
        embedding_vectors = embedding_vectors.transpose(1, 2)
        filter_outputs = [self._conv_layer_activation(filter(self.dropout(embedding_vectors))).max(dim=-1)[0]
                          for filter in self.cnn_filters]
        maxpool_outputs = torch.cat(filter_outputs, dim=1) if len(filter_outputs) > 1 else filter_outputs[0]
        maxpool_outputs = maxpool_outputs.squeeze(-1)
        highway_outputs = self.highway(maxpool_outputs)
        outputs = self.linear(self.dropout(highway_outputs))
        logits = function(outputs)

        return logits


class Highway(nn.Module):
    def __init__(self,
                 input_dim: int,
                 num_layers: int = 1,
                 activation=F.relu) -> None:
        super(Highway, self).__init__()
        self.input_dim = input_dim
        self.layers = nn.ModuleList([nn.Linear(input_dim, input_dim * 2)
                                  for _ in range(num_layers)])
        self.activation = activation
        #for layer in self.layers:
            # We should bias the highway layer to just carry its input forward.  We do that by
            # setting the bias on `B(x)` to be positive, because that means `g` will be biased to
            # be high, to we will carry the input forward.  The bias on `B(x)` is the second half
            # of the bias vector in each Linear layer.
            #layer.bias[input_dim:].data.fill_(1)

    def forward(self, inputs: torch.FloatTensor) -> torch.FloatTensor:
        '''
        inputs dim: (batch_size X some other dims X vector_dims)
        '''
        original_inputs = inputs
        if original_inputs.dim() > 2:
            inputs = inputs.view(-1, inputs.size(-1))

        current_input = inputs
        for layer in self.layers:
            projected_input = layer(current_input)
            linear_part = current_input
            nonlinear_part = projected_input[:, (0 * self.input_dim): (1 * self.input_dim)]
            gate = projected_input[:, (1 * self.input_dim): (2 * self.input_dim)]
            nonlinear_part = self.activation(nonlinear_part)
            gate = torch.nn.functional.sigmoid(gate)
            current_input = gate * linear_part + (1 - gate) * nonlinear_part

        if original_inputs.dim() > 2:
            view_args = list(original_inputs.size())
            current_input = current_input.view(*view_args)

        return current_input
