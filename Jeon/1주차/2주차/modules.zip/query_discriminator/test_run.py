import torch
from torch.autograd import Variable

from konlpy.tag import Kkma

import numpy as np

MIN_LENGTH = 5


def tokenize(str_input):
    str_input = str_input.replace(" ", "")
    ch_list = [ch for ch in str_input]
    return ch_list
    #kkma = Kkma()
    #morph_list = kkma.morphs(str_input)
    #return morph_list
    #return str_input.split()


def recommend_threshold(model, vocab, path='./data/train.txt'):
    f = open(path, 'r')
    examples = f.readlines()
    scores = list()

    for e in examples:
        input_str = e.replace("\n", "")
        input_variable, _ = prepro_str(input_str, vocab)
        logit = model(input_variable)
        scores.append(logit.data[0])

    mean, std = np.mean(scores), np.std(scores)

    return mean, std


def prepro_str(str_input, vocab):
    tokenized_list = tokenize(str_input)
    stuffing_len = MIN_LENGTH - len(tokenized_list)
    stuffing_len = stuffing_len if stuffing_len > 0 else 0
    indexed_tokens = [vocab.stoi[tok] for tok in tokenized_list] + [vocab.stoi['<pad>']] * stuffing_len
    return Variable(torch.LongTensor([indexed_tokens])), tokenized_list


loaded_model = torch.load('./model/test_model.pt')

vocab = loaded_model['vocab']
model = loaded_model['model']

mean, std = recommend_threshold(model, vocab)

print("data stats: mean: ", mean, ", std:", std)

while True:
    seq_str = input("Type in a source sequence:")
    input_variable, tokenized = prepro_str(seq_str, vocab)
    print("morphs: ", tokenized)
    print("input variable: ", input_variable)
    logit = model(input_variable)
    print("score: ", logit.data[0])
