from torch import nn


class WordEmbedding(nn.Module):
    def __init__(self,
                 word_size,
                 embedding_dim,
                 weight=None,
                 trainable=True):
        super(WordEmbedding, self).__init__()

        self._word_size = word_size
        self._embedding_dim = embedding_dim

        self.embedding = nn.Embedding(word_size, embedding_dim)

        if weight:
            self.embedding.weight = nn.Parameter(weight)

        if not trainable:
            self.embedding.requires_grad = False

    def forward(self, inputs):
        '''
        Word Embedding Dim Setting

        Input Dim: [Batch_dim, Sequence_dim]
        Output Dim: [Batch_dim, Sequence_dim, embedding dim]
        '''
        outputs = self.embedding(inputs)

        return outputs
