import os
import sys
sys.path.append('../../')

import torch
from torch import nn
from torch import optim
from torch.autograd import Variable

import torchtext
from torchtext.data import Field
from torchtext.data import BucketIterator

from konlpy.tag import Kkma

from modules.query_discriminator.embedding import WordEmbedding
from modules.query_discriminator.discriminator import Discriminator

MIN_LENGTH = 5
SRC_FIELD_NAME = 'src'


def tokenize(str_input):
    str_input = str_input.replace(" ", "")
    ch_list = [ch for ch in str_input]
    return ch_list
    #kkma = Kkma()
    #morph_list = kkma.morphs(str_input)
    #return morph_list
    #return str_input.split()


def prepro_str(str_input, vocab):
    tokenized_list = tokenize(str_input)
    stuffing_len = MIN_LENGTH - len(tokenized_list)
    stuffing_len = stuffing_len if stuffing_len > 0 else 0
    indexed_tokens = [vocab.stoi[tok] for tok in tokenized_list] + [vocab.stoi['<pad>']] * stuffing_len
    return Variable(torch.LongTensor([indexed_tokens])), tokenized_list


current_path = os.path.dirname(__file__)
file_path = "data/train.txt"

src = Field(tokenize=tokenize, batch_first=True)

train = torchtext.data.TabularDataset(path=os.path.join(current_path, file_path), format='tsv',
                                      fields=[(SRC_FIELD_NAME, src)])

print(len(train.examples))

src.build_vocab(train.src)

vocab = train.fields['src'].vocab

prepro_str("호텔 비용이 얼마나 드나요?", vocab)

n_epochs, batch_size = 10, 16

word_size, embedding_dim = len(src.vocab), 32
num_filters, ngram = 64, [2, 2, 3, 3, 4, 4]

word_embedding = WordEmbedding(word_size, embedding_dim)
model = Discriminator(embedding_dim, num_filters, ngram, word_embedding)

batch_iterator = BucketIterator(dataset=train, batch_size=batch_size, sort=False, sort_within_batch=True,
                                sort_key=lambda x: len(x.src), repeat=False, device=-1)

criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), weight_decay=.05)

for _ in range(n_epochs):
    batch_generator = batch_iterator.__iter__()
    for i, batch in enumerate(batch_generator):
        input_variable = getattr(batch, SRC_FIELD_NAME)
        if input_variable.size(1) < MIN_LENGTH:
            pad = Variable(torch.zeros(batch_size, MIN_LENGTH-input_variable.size(1))).type(torch.LongTensor)
            input_variable = torch.cat((input_variable, pad), dim=-1)

        real_labels = Variable(torch.ones(input_variable.size(0)))
        outputs = model(input_variable)
        loss = criterion(outputs, real_labels)

        model.zero_grad()
        loss.backward()
        optimizer.step()

        msg = "%d th step loss : %.2f" % (i, loss.data[0])
        print(msg)

saving_model = {"model": model, "vocab": vocab}
torch.save(saving_model, "./model/test_model.pt")
