import torch
from torch.autograd import Variable


class QueryDiscriminatorAgent(object):
    def __init__(self, path='/home/teddy/projects/teddies/modules/query_discriminator/model/test_model.pt',
                 seq_minimum_len=5):
        self.model_path = path
        self.model = None
        self.vocab = None

        self.mean = None
        self.std = None

        self.MIN_LENGTH = seq_minimum_len

        self._load_model()
        self._set_stats()

    def _load_model(self):
        loaded_model = torch.load(self.model_path)
        self.model = loaded_model['model']
        self.vocab = loaded_model['vocab']

    def _tokenize(self, str_input):
        str_input = str_input.replace(" ", "")
        ch_list = [ch for ch in str_input]

        return ch_list

    def _set_stats(self, path='/home/teddy/projects/teddies/modules/query_discriminator/data/train.txt'):
        import numpy as np

        f = open(path, 'r')
        examples = f.readlines()
        scores = list()

        for e in examples:
            input_str = e.replace("\n", "")
            input_variable = self._prepro_str(input_str)
            logit = self.model(input_variable)
            scores.append(logit.data[0])

        self.mean, self.std = np.mean(scores), np.std(scores)

    def _prepro_str(self, str_input):
        tokenized_list = self._tokenize(str_input)
        stuffing_len = self.MIN_LENGTH - len(tokenized_list)
        stuffing_len = stuffing_len if stuffing_len > 0 else 0
        indexed_tokens = [self.vocab.stoi[tok] for tok in tokenized_list] + [self.vocab.stoi['<pad>']] * stuffing_len

        return Variable(torch.LongTensor([indexed_tokens]))

    def get_threshold(self, sigma=6):
        return self.mean - (self.std * sigma)

    def get_score(self, str_input):
        input_variable = self._prepro_str(str_input)
        logit = self.model(input_variable)

        return logit.data.cpu().numpy()[0]
