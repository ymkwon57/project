model_path = '/home/teddy/projects/teddies/modules/entity_tagger/model/model_real_final2.pkl'
w2v_path = '/home/teddy/projects/teddies/modules/entity_tagger/data_in/word2vec/w2v_0328.model'
vocab_file_path = '/home/teddy/projects/teddies/modules/entity_tagger/data_in/newdata/vocabs_0328.json'

predict_NER_dict = {0: '<PAD>',
                    1: '<START>',
                    2: '<STOP>',
                    3: 'B_CV',
                    4: 'B_QT',
                    5: 'B_OG',
                    6: 'B_LC',
                    7: 'B_ES',
                    8: 'B_TI',
                    9: 'I',
                    10: 'O'}

label_NER_dict = {3: 'CV',
                  4: 'QT',
                  5: 'OG',
                  6: 'LC',
                  7: 'ES',
                  8: 'TI',
                  9: 'I'}
