import numpy as np
import pickle
import torch
import re
from torch.autograd import Variable
from gensim.models import word2vec
from konlpy.tag import Twitter
from modules.entity_tagger.data_loader import prepare_sequence, prepare_char_sequence, prepare_lex_sequence
from modules.entity_tagger.configs import *

'''
wv_model_ko = word2vec.Word2Vec.load(w2v_path)
word2vec_matrix = wv_model_ko.wv.syn0
twitter = Twitter()

with open(vocab_path, 'rb') as f:
    vocab = pickle.load(f)

with open(char_vocab_path, 'rb') as f:
    char_vocab = pickle.load(f)

with open(pos_vocab_path, 'rb') as f:
    pos_vocab = pickle.load(f)

with open(lex_dict_path, 'rb') as f:
    lex_dict = pickle.load(f)
'''



class Vocabulary():
    def __init__(self):
        self.word2idx = {}
        self.idx2word = {}
        self.idx = 0

    def add_word(self, word):
        self.word2idx[word] = self.idx
        self.idx2word[self.idx] = word
        self.idx += 1

    def __len__(self):
        return len(self.word2idx)

def to_np(x):
    return x.data.cpu().numpy()

def to_var(x, volatile=False):
    if torch.cuda.is_available():
        x = x.cuda(gpu_index)
    return Variable(x, volatile=volatile)

predict_NER_dict = {0: '<PAD>',
                    1: '<START>',
                    2: '<STOP>',
                    3: 'B_CV',
                    4: 'B_QT',
                    5: 'B_OG',
                    6: 'B_LC',
                    7: 'B_ES',
                    8: 'B_TI',
                    9: 'I',
                    10: 'O'}

NER_idx_dic = {'<unk>': 0, 'CV': 1, 'QT': 2, 'OG': 3, 'LC': 4, 'ES': 5, 'TI': 6}



twitter = Twitter()

def load_data_and_labels(input_str):
    # Load data_in from files
    x_mor_list = list()
    x_pos_list = list()
    x_split_list = list()
    y_list = list()

    lines = [input_str]
    NER_label_list = {'<unk>': 0, 'CV': 1, 'QT': 2, 'OG': 3, 'LC': 4, 'ES': 5, 'TI': 6}

    NER_dict = {'<PAD>':   [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                '<START>': [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                '<STOP>':  [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                'B_CV':    [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                'B_QT':    [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
                'B_OG':    [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
                'B_LC':    [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                'B_ES':    [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
                'B_TI':    [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
                'I':       [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
                'O':       [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]}

    NER_list = [[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0],
                [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]]
    re_word = re.compile('<(.+?):[A-Z]{2}>')

    for line in lines:
        line = line.replace(' ','')
        line = line.strip()
        raw_data = line.replace('<', '').replace('>', '').replace(':CV', '').replace(':QT', '').replace(':OG',
                                                                                                        '').replace(
            ':LC', '').replace(':ES', '').replace(':TI', '')
        split_raw_data = raw_data.split(' ')
        pos_data = twitter.pos(raw_data)

        x_split = []
        x_mor = []
        x_pos = []

        i = 0
        len_pos_word = 0
        len_split_word = 0
        for mor_pos in pos_data:
            if mor_pos[0] in split_raw_data[i]:
                len_pos_word += len(mor_pos[0])
                len_split_word = len(split_raw_data[i])

                # new_pos_data.append([i, pos_word[0], pos_word[1]])

                x_split.append(i)
                x_mor.append(mor_pos[0])
                x_pos.append(mor_pos[1])

                if len_pos_word == len_split_word:
                    i = i + 1
                    len_pos_word = 0
                    len_split_word = 0

        if len(x_mor) == 0:  # mecab에러인지... 가끔 하나가 빠짐 그거 제외
            continue

        x_mor_list.append(x_mor)
        x_pos_list.append(x_pos)
        x_split_list.append(x_split)

        # label data
        label_data = line
        label_split_data = label_data.split(' ')

        re_result = re_word.finditer(label_data)
        raw_re_word_list = []
        temp_re_word_list = []
        re_NER_list = []
        for re_result_item in re_result:
            re_NER_list.append(re_result_item.group()[-3:-1])
            raw_re_word_list.append(re_word.findall((re_result_item.group())))
            temp_re_word_list.append(re_word.findall((re_result_item.group()[1:])))
            for i, temp_re_word_item in enumerate(temp_re_word_list):
                if len(temp_re_word_item) != 0:
                    raw_re_word_list[i] = temp_re_word_item

        # re_NER_list = re_NER.findall(label_data)
        re_word_list = [[re_word[0].replace(' ', '')] for re_word in raw_re_word_list]
        # print("re_word_list:",re_word_list)

        y_data = ['O'] * len(x_mor)
        B_flag = 0
        data_len = 0
        B_I_data_len = 0

        for i in range(len(x_mor)):
            pos_i_split = x_split[i]
            word_mor = x_mor[i]
            pos = x_pos[i]

            if len(re_word_list) == 0:
                continue

            if word_mor in re_word_list[0][0]:

                # print("word_mor:", word_mor)
                # print("data_len:", data_len)
                # print("B_I_data_len:", B_I_data_len)

                if B_flag == 0 and re_word_list[0][0].startswith(word_mor):

                    data_len += len(word_mor)
                    B_I_data_len = len(re_word_list[0][0])

                    y_data[i] = 'B_' + re_NER_list[0]
                    B_flag = 1  # B_ token mark

                    if data_len == B_I_data_len:
                        re_word_list.pop(0)
                        re_NER_list.pop(0)

                        data_len = 0
                        B_I_data_len = 0
                        B_flag = 0  # B_ token mark init


                    elif i + 1 < len(x_mor):
                        if x_mor[i + 1] not in re_word_list[0][0]:  # 시작일줄 알았는데 서브스트링이고, 매칭도 안되고 다음글자가 속하지 않으면 다시 리셋
                            y_data[i] = 'O'
                            B_flag = 0
                            data_len = 0
                            B_I_data_len = 0
                            B_flag = 0  # B_ token mark init


                elif B_flag == 1:

                    data_len += len(word_mor)
                    B_I_data_len = len(re_word_list[0][0])

                    if data_len != B_I_data_len:
                        y_data[i] = 'I'
                    elif data_len == B_I_data_len:
                        y_data[i] = 'I'
                        re_word_list.pop(0)
                        re_NER_list.pop(0)
                        data_len = 0
                        B_I_data_len = 0
                        B_flag = 0

        # print("y_data: ", y_data)
        y_data_idx = []
        for y in y_data:
            y_data_idx.append(NER_dict[y])
        y_list.append(y_data_idx)
        target_list = []
        # for yy in y_list:
        #    tmp = []
        #    for idx in range(len(yy)):
        #        for i in range(len(NER_list)):
        #            if(yy[idx]==NER_list[i]):
        #                tmp.append(i)
        #    target_list.append(tmp)

        for idx in range(len(y_list[0])):
            for i in range(len(NER_list)):
                if (y_list[0][idx] == NER_list[i]):
                    target_list.append(i)

    return x_mor_list, x_pos_list, x_split_list, target_list

def preprocessing(x_text_batch, x_pos_batch, x_split_batch,vocab,char_vocab,pos_vocab,lex_dict):
    x_text_char_item = []
    for x_word in x_text_batch[0]:
        x_char_item = []
        for x_char in x_word:
            x_char_item.append(x_char)
        x_text_char_item.append(x_char_item)
    x_text_char_batch = [x_text_char_item]

    x_idx_item = prepare_sequence(x_text_batch[0], vocab['word2idx'])
    x_idx_char_item = prepare_char_sequence(x_text_char_batch[0], char_vocab['word2idx'])
    x_pos_item = prepare_sequence(x_pos_batch[0], pos_vocab['word2idx'])
    x_lex_item = prepare_lex_sequence(x_text_batch[0], lex_dict)

    x_idx_batch = [x_idx_item]
    x_idx_char_batch = [x_idx_char_item]
    x_pos_batch = [x_pos_item]
    x_lex_batch = [x_lex_item]

    max_word_len = int(
        np.amax([len(word_tokens) for word_tokens in x_idx_batch]))  # ToDo: usually, np.mean can be applied
    batch_size = len(x_idx_batch)
    batch_words_len = [len(word_tokens) for word_tokens in x_idx_batch]
    batch_words_len = np.array(batch_words_len)

    # Padding procedure (word)
    padded_word_tokens_matrix = np.zeros((batch_size, max_word_len), dtype=np.int64)
    for i in range(padded_word_tokens_matrix.shape[0]):
        for j in range(padded_word_tokens_matrix.shape[1]):
            try:
                padded_word_tokens_matrix[i, j] = x_idx_batch[i][j]
            except IndexError:
                pass

    max_char_len = int(np.amax([len(char_tokens) for word_tokens in x_idx_char_batch for char_tokens in word_tokens]))
    if max_char_len < 5:  # size of maximum filter of CNN
        max_char_len = 5

    # Padding procedure (char)
    padded_char_tokens_matrix = np.zeros((batch_size, max_word_len, max_char_len), dtype=np.int64)
    for i in range(padded_char_tokens_matrix.shape[0]):
        for j in range(padded_char_tokens_matrix.shape[1]):
            for k in range(padded_char_tokens_matrix.shape[1]):
                try:
                    padded_char_tokens_matrix[i, j, k] = x_idx_char_batch[i][j][k]
                except IndexError:
                    pass

    # Padding procedure (pos)
    padded_pos_tokens_matrix = np.zeros((batch_size, max_word_len), dtype=np.int64)
    for i in range(padded_pos_tokens_matrix.shape[0]):
        for j in range(padded_pos_tokens_matrix.shape[1]):
            try:
                padded_pos_tokens_matrix[i, j] = x_pos_batch[i][j]
            except IndexError:
                pass

    # Padding procedure (lex)
    padded_lex_tokens_matrix = np.zeros((batch_size, max_word_len, len(NER_idx_dic)))
    for i in range(padded_lex_tokens_matrix.shape[0]):
        for j in range(padded_lex_tokens_matrix.shape[1]):
            for k in range(padded_lex_tokens_matrix.shape[2]):
                try:
                    for x_lex in x_lex_batch[i][j]:
                        if(x_lex in ['PS','DT']):
                            pass
                        else:
                            k = NER_idx_dic[x_lex]
                            padded_lex_tokens_matrix[i, j, k] = 1
                except IndexError:
                    pass

    x_text_batch = x_text_batch
    x_split_batch = x_split_batch
    padded_word_tokens_matrix = torch.from_numpy(padded_word_tokens_matrix)
    padded_char_tokens_matrix = torch.from_numpy(padded_char_tokens_matrix)
    padded_pos_tokens_matrix = torch.from_numpy(padded_pos_tokens_matrix)
    padded_lex_tokens_matrix = torch.from_numpy(padded_lex_tokens_matrix).float()
    lengths = batch_words_len

    return x_text_batch, x_split_batch, padded_word_tokens_matrix, padded_char_tokens_matrix, padded_pos_tokens_matrix, padded_lex_tokens_matrix, lengths

#def loadPickle(dir):
#    print(dir)
#    with open(dir,'rb') as f:
#        tmp = pickle.load(f)
#    return tmp
