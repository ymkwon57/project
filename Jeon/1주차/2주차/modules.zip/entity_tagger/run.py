from modules.entity_tagger.jslib import preprocessing,load_data_and_labels,to_var
from modules.entity_tagger.bilstm import CNNBiLSTM
from gensim.models import word2vec
import torch
from modules.entity_tagger.configs import *
from modules.entity_tagger.data_utils import main
import json

num_layers = 2
embed_size = 100
hidden_size = 200
gpu_index = 0


class Tagger():

    def __init__(self,**kwargs):
        self.vocab = None # member variable: instance 안의 변수(상주)
        self.char_vocab = None
        self.pos_vocab = None
        self.NER_idx_dic = None
        self.lex_dict = None
        self.word2vec_matrix = None
        self._set_data()
        self.model = CNNBiLSTM(vocab_size=len(self.vocab['idx2word']),
                          char_vocab_size=len(self.char_vocab['idx2word']),
                          pos_vocab_size=len(self.pos_vocab['idx2word']),
                          lex_ner_size=len(self.NER_idx_dic),
                          embed_size= embed_size,
                          hidden_size= hidden_size,
                          num_layers= num_layers,
                          word2vec= self.word2vec_matrix,
                          num_classes=11)

        self.model.load_state_dict(torch.load(model_path, map_location=lambda storage, loc: storage))

    def _set_data(self):
        self.NER_idx_dic = {'<unk>': 0, 'CV': 1, 'QT': 2, 'OG': 3, 'LC': 4, 'ES': 5, 'TI': 6}
        wv_model_ko = word2vec.Word2Vec.load(w2v_path)
        self.word2vec_matrix = wv_model_ko.wv.syn0
        json_data = open(vocab_file_path).read()
        vocab_set = json.loads(json_data)
        self.vocab = vocab_set["word_vocab"]
        self.char_vocab = vocab_set["char_vocab"]
        self.pos_vocab = vocab_set["pos_vocab"]
        self.lex_dict = vocab_set["lex_dict"]


    def tag(self,input_str):
        self.model.eval()
        x_text_batch, x_pos_batch, x_split_batch, y_list = load_data_and_labels(input_str)
        x_text_batch, x_split_batch, padded_word_tokens_matrix, padded_char_tokens_matrix, padded_pos_tokens_matrix, padded_lex_tokens_matrix, lengths = preprocessing(x_text_batch, x_pos_batch, x_split_batch,self.vocab,self.char_vocab,self.pos_vocab,self.lex_dict)
        # Test
        padded_word_tokens_matrix = to_var(padded_word_tokens_matrix)
        padded_char_tokens_matrix = to_var(padded_char_tokens_matrix)
        padded_pos_tokens_matrix = to_var(padded_pos_tokens_matrix)
        padded_lex_tokens_matrix = to_var(padded_lex_tokens_matrix)

        predictions = self.model.sample(padded_word_tokens_matrix, padded_char_tokens_matrix,
                                   padded_pos_tokens_matrix, padded_lex_tokens_matrix, lengths)

        max_predictions, argmax_predictions = predictions.max(2)

        result = []
        ll = argmax_predictions.data.numpy()

        for k in range(len(x_text_batch[0])):
            if(ll[0][k]==10):
                pass
            elif(ll[0][k]==9 and not len(result) == 0):
                result[len(result)-1] = (str(result[len(result)-1][0]) + x_text_batch[0][k],str(result[len(result)-1][1]))
            else:
                result.append((x_text_batch[0][k], label_NER_dict[ll[0][k]]))

        return list(set(result))
