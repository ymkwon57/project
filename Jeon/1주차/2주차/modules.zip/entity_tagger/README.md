# Data Driven Dialogue System
## Entity Tagger (BiLSTM-CNN)
### env
    * Python 3.6.1
    * Pytorch 0.6.0
    * Gensim 3.0.0
    * (optional) Konlpy 0.4.4 Twitter

## 1. Input ,Output
### Input

  for Training you need tagged data

  ex) <오늘:DT> <조식:CV> 제공되나요?

  for Testing, you need row data

  ex) 오늘 조식 제공되나요?

### Output

  NE tagged token (tuple)

  ex)
    input> 오늘 조식 제공되나요?
    output> (오늘,DT) , (조식,CV)


## 2. project path

### current directory
    * /modules/entity_tagger


## 3. How to Train

    * python train.py
______________________________
### Params
    model = CNNBiLSTM(vocab_size = vocabulary size),
                       char_vocab_size= character vocab size),
                        pos_vocab_size= pos vocab size(by Twitter)),
                        lex_ner_size= ne dictionary size,
                        embed_size = embedding dimension,
                        hidden_size = hidden layer dimension,
                        num_layers = # of layer,
                        word2vec = if you had pretrained_word2vec model, use this,
                        num_classes = target size)

______________________________
###4 How to Predict

    from run import Tagger

    tagger = Tagger()

    tagger.tag('your_input_str')

______________________________
### load pretrained model

    self.model.load_state_dict(torch.load(model_path,map_location=lambda storage,loc:storage))


### Author

    Jisoo Kim

    last commit : 18/04/05
