from modules.entity_tagger.data_utils import *
