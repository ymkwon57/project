import numpy as np
import pickle
import torch
import torch.nn as nn
import re
import json
from torch import Tensor
from torch.autograd import Variable
from jslib import preprocessing,load_data_and_labels
from bilstm import CNNBiLSTM
from konlpy.tag import Twitter
from gensim.models import word2vec
import random
from sklearn.metrics import f1_score
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report
from itertools import chain


num_layers = 2
num_epochs = 100
num_samples = 1000   # number of words to be sampled
batch_size = 20
seq_length = 30
learning_rate = 0.002
embed_size=100
hidden_size=200
gpu_index=0

predict_NER_dict = {0: '<PAD>',
                    1: '<START>',
                    2: '<STOP>',
                    3: 'B_CV',
                    4: 'B_QT',
                    5: 'B_OG',
                    6: 'B_LC',
                    7: 'B_ES',
                    8: 'B_TI',
                    9: 'I',
                    10: 'O'}

NER_idx_dic = {'<unk>': 0, 'CV': 1, 'QT': 2, 'OG': 3, 'LC': 4, 'ES': 5, 'TI': 6}


pretrained_word2vec_file = './data_in/word2vec/hotel_1000.model'
wv_model_ko = word2vec.Word2Vec.load(pretrained_word2vec_file)
word2vec_matrix = wv_model_ko.wv.syn0
twitter = Twitter()

json_data = open('./data_in/newdata/vocabs.json').read()

vocab_set = json.loads(json_data)

vocab = vocab_set["word_vocab"]
char_vocab = vocab_set["char_vocab"]
pos_vocab = vocab_set["pos_vocab"]
lex_dict = vocab_set["lex_dict"]



def to_np(x):
    return x.data.cpu().numpy()

def to_var(x, volatile=False):
    if torch.cuda.is_available():
        x = x.cuda(gpu_index)
    return Variable(x, volatile=volatile)


model = CNNBiLSTM(vocab_size=len(vocab['idx2word']),
                                     char_vocab_size=len(char_vocab['idx2word']),
                                        pos_vocab_size=len(pos_vocab['idx2word']),
                                        lex_ner_size=len(NER_idx_dic),
                                        embed_size=embed_size,
                                        hidden_size=hidden_size,
                                        num_layers=num_layers,
                                        word2vec=word2vec_matrix,
                                        num_classes=11)

criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=0.002)
optimizer_L2 = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=0.002,weight_decay=0.01)


with open('./data_in/hotel_tagged_final.pkl', 'rb') as f:
    tagged = pickle.load(f)

model.train(True)


for epoch in range(num_epochs):
    random.shuffle(tagged)
    losses = []
    f_measure = []
    accuarcy = []
    y_true = []
    y_pred = []
    for i, index in enumerate(np.random.permutation(len(tagged))):
        x_text_batch, x_pos_batch, x_split_batch, y_list = load_data_and_labels(tagged[index])
        x_text_batch, x_split_batch, padded_word_tokens_matrix, padded_char_tokens_matrix, padded_pos_tokens_matrix, padded_lex_tokens_matrix, lengths = preprocessing(
            x_text_batch, x_pos_batch, x_split_batch,vocab,char_vocab,pos_vocab,lex_dict)

        y_true.append(y_list)
        # Test
        padded_word_tokens_matrix = to_var(padded_word_tokens_matrix)
        padded_char_tokens_matrix = to_var(padded_char_tokens_matrix)
        padded_pos_tokens_matrix = to_var(padded_pos_tokens_matrix)
        padded_lex_tokens_matrix = to_var(padded_lex_tokens_matrix)

        model.zero_grad()
        predictions = model.sample(padded_word_tokens_matrix, padded_char_tokens_matrix,
                                               padded_pos_tokens_matrix, padded_lex_tokens_matrix, lengths)

        max_predictions, argmax_predictions = predictions.max(2)

        loss = criterion(predictions[0], Variable(torch.LongTensor(y_list)))
        loss.backward()  # 역전파
        losses.append(loss.data[0])

        y_true.append(y_list)
        y_pred.append(argmax_predictions.data.numpy()[0])

        f_measure.append(f1_score(y_list, argmax_predictions.data.numpy()[0], average='micro'))
        accuarcy.append(accuracy_score(y_list, argmax_predictions.data.numpy()[0]))

        torch.nn.utils.clip_grad_norm(model.parameters(), 0.5)

        optimizer.step()  # 파라미터 업뎃
        step = (i + 1)

        if(step % 100 == 0):
            print(
                'Epoch [%d/%d], Step : %d, Train Loss: %.3f, train_f1_score: %5.2f, Train Accuarcy: %5.2f' %
                (epoch + 1, num_epochs, step, np.mean(losses),np.mean(f_measure[-50:]),np.mean(accuarcy)))
            print(max_f1_score,np.mean(f_measure))

            if(step>200 and max_f1_score < np.mean(f_measure)):
                max_f1_score = np.mean(f_measure)
                print('the checkpoint f1 score is: ',np.mean(f_measure),'and accuracy is: ',np.mean(accuaracy))
                torch.save(model.state_dict(),'./data_in/max_fscore_model.pkl')
            else:
                pass

    print(classification_report(list(chain(*y_true)),list(chain(*y_pred))))

torch.save(model.state_dict(), 'model_full_epoch.pkl')
