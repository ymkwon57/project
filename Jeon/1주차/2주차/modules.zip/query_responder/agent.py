import random
import math
import numpy as np

import pandas as pd


VERY_SMALL_FRACTION = 1e-6


class SingleQueryRespondAgent(object):
    def __init__(self, model_path='/home/teddy/projects/teddies/modules/query_responder/data/model.csv'):
        self.path = model_path
        self.model = None

        self._load_model()

    def _load_model(self):
        self.model = pd.read_csv(self.path)

    def _process(self, intent, entities, nouns):

        model = self.model
        ner_scores = None
        noun_scores = None

        if intent is not None:
            intent_filtered = model.loc[model['Intent'] == intent]
        else:
            intent_filtered = model

        if entities is not None:
            ner_scores = list()
            rev_ner_scores = list()
            entities = [item[0] for item in entities]
        if nouns is not None:
            noun_scores = list()
            rev_noun_scores = list()

        def get_score(src_list, tgt_list):
            total = len(tgt_list) if len(tgt_list) > 0 else VERY_SMALL_FRACTION
            correct = VERY_SMALL_FRACTION
            for e in src_list:
                if e in tgt_list:
                    correct += 1
            return correct / total

        def evaluate_scores(_ner_scores, _noun_scores):
            evaluated_scores = list()
            for ner, noun in zip(_ner_scores, _noun_scores):
                evaluated_scores.append(math.sqrt(ner * noun))
            return evaluated_scores

        for index, row in intent_filtered.iterrows():
            if entities is not None:
                row_entities = [item[0] for item in eval(row["Entities"])]
                ner_scores.append(get_score(entities, row_entities))
                rev_ner_scores.append(get_score(row_entities, entities))
            if nouns is not None:
                row_nouns = eval(row["Nouns"])
                noun_scores.append(get_score(nouns, row_nouns))
                rev_noun_scores.append(get_score(row_nouns, nouns))

        if entities is not None and nouns is not None:
            eval_scores = evaluate_scores(ner_scores, noun_scores)
            rev_eval_scores = evaluate_scores(rev_ner_scores, rev_noun_scores)
            eval_scores = np.divide(np.add(eval_scores, rev_eval_scores), 2)
        elif entities is not None:
            eval_scores = ner_scores
        else:
            eval_scores = noun_scores

        max_score = max(eval_scores)

        if max_score < VERY_SMALL_FRACTION:
            return "Not Matched Response", max_score

        unique_entries = set(eval_scores)
        score_indices = {value: [i for i, v in enumerate(eval_scores) if v == value]
                         for value in unique_entries}
        #print(len(score_indices[max_score]), score_indices[max_score])
        selected_index = random.choice(score_indices[max_score])
        #selected_index = eval_scores.index(max_score)

        responses = list(intent_filtered["Response"])
        ground_truth_entities = list(intent_filtered["Entities"])
        ground_truth_nouns = list(intent_filtered["Nouns"])
        #print("Entity score: ", ner_scores[selected_index])
        #print("Noun score: ", noun_scores[selected_index])
        #print("GT Entity :", ground_truth_entities[selected_index])
        #print("GT Noun :", ground_truth_nouns[selected_index])

        return responses[selected_index], max_score

    def forward(self, input):
        _intent = input["Intent"] if "Intent" in input else None
        _entities = input["Entities"] if "Entities" in input else None
        _nouns = input["Nouns"] if "Nouns" in input else None

        response, score = self._process(_intent, _entities, _nouns)

        return {"response": response, "score": score}


# Test Example

'''
agent = SingleQueryRespondAgent()

sample_data = {"Intent": "결제",
               "Entities": [("상품권", "CV")]}

report = agent.forward(sample_data)
print(report)
'''
