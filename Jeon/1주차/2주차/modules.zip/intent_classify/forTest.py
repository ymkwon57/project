from dslib import openCsv, assambleData, tokenizer
from dictionarize import Word2Vec

space_sig = '▿'
token_option = 'char'
dict_path = './default_embed/'

enc, dec = openCsv(dict_path,'big.txt', sep=',')
print(enc[:10])
print(dec[:10])

enc, encode_length = assambleData(enc, space_sig, token_option, tokenizer)
print(enc[:10])

w2v = Word2Vec(token_option, dict_path, 5, 50, 100)#def __init__(self, token_option, dict_path, w2v_window, w2v_size, w2v_epoch):
model = w2v.getWord2Vec(enc, 1)
'''
#default_d2v.model_char
from gensim.models import Doc2Vec
model = Doc2Vec.load(dict_path + 'default_d2v.model_char' )
print(model.layer1_size)
'''