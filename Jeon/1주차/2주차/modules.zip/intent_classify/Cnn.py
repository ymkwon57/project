import tensorflow as tf
from modules.intent_classify.dslib import getEncDec, kfoldValidation, checkPath, tokenizer, getModel, openCsv, makeRaw, loadPickle, savePickle, softmax


space_sig = '▿'

#model_path = './models/'
model_path = '/home/teddy/projects/teddies/modules/intent_classify/models/'
w2v_path =  '/home/teddy/projects/teddies/modules/intent_classify/default_embed/'

filter_type = "multi"
filter_sizes = [2, 3, 5, 2, 3, 5, 2, 3, 5]
num_filters = len(filter_sizes)

class hps:
    def __init__(self, **kwargs):
        self.args = kwargs

    def checkArgs(self):
        print(self.args)

    def getArgs(self):
        return self.args

class Cnn_Train:

    def __init__(self, **kwargs):

        self._story_id = kwargs.get('story_id', 'user1') # 3DS에는 모델을 구분지을 유니크가
        self._path = model_path + self._story_id + '/'
        self._epoch = kwargs.get('epoch',11)
        self._token_option = kwargs.get('token_option','char')
        self._learning_rate = kwargs.get('learning_rate',1e-3)
        self._k_fold = kwargs.get('k_fold', 5)
        self._batch_size = kwargs.get('batch_size',32)

        self._w2v_model = kwargs.get('w2v_model', getModel(w2v_path, self._token_option))  # default w2v?
        self._model_option = kwargs.get('model_option', 'embed')
        self._w2v_dim = len(self._w2v_model.wv.index2word) if self._model_option == 'one_hot' else self._w2v_model.layer1_size


        data = kwargs.get('data','') # 'intent,example\n ...'
        self._enc, self._dec = getEncDec(data.split('\n'), sep=',')
        self._label_size = len(set(self._dec))
        self._enc, self._encode_length = self.assambleData(self._enc, space_sig, self._token_option,
                                                        tokenizer)
        self._dec_dic = self.getLabelForCnn(self._dec)
        self._dec = [self._dec_dic[d] for d in self._dec]


        val_key = {v: k for k, v in self._dec_dic.items()}
        hps_class = {
            'token_option':self._token_option,
            'encode_length':self._encode_length,
            'label_size':self._label_size,
            'learning_rate':self._learning_rate,
            'val_key':val_key
        }
        savePickle(self._path, 'hps.pkl', hps_class)


    def create_m_graph(self, train=True):
        # placeholder is used for feeding data.
        x = tf.placeholder("float", shape=[None, self._encode_length * self._w2v_dim], name='x')
        y_target = tf.placeholder("float", shape=[None, self._label_size], name='y_target')

        # reshape input data
        x_image = tf.reshape(x, [-1, self._encode_length, self._w2v_dim, 1], name="x_image")
        # Keeping track of l2 regularization loss (optional)
        l2_loss = tf.constant(0.0)

        pooled_outputs = []
        for i, filter_size in enumerate(filter_sizes):
            with tf.name_scope("conv-maxpool-%s" % filter_size):
                # Convolution Layer
                filter_shape = [filter_size, self._w2v_dim, 1, num_filters]
                W_conv1 = tf.Variable(tf.truncated_normal(filter_shape, stddev=0.1), name="W")
                b_conv1 = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                conv = tf.nn.conv2d(
                    x_image,
                    W_conv1,
                    strides=[1, 1, 1, 1],
                    padding="VALID",
                    name="conv")

                # Apply nonlinearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b_conv1), name="relu")
                # Maxpooling over the outputs
                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, self._encode_length - filter_size + 1, 1, 1],
                    strides=[1, 1, 1, 1],
                    padding='VALID',
                    name="pool")
                pooled_outputs.append(pooled)

        # Combine all the pooled features
        num_filters_total = num_filters * len(filter_sizes)
        h_pool = tf.concat(pooled_outputs, 3)
        h_pool_flat = tf.reshape(h_pool, [-1, num_filters_total])

        # Add dropout
        keep_prob = 1.0
        if (train):
            keep_prob = tf.placeholder("float", name="keep_prob")
            h_pool_flat = tf.nn.dropout(h_pool_flat, keep_prob)

        # Final (unnormalized) scores and predictions
        W_fc1 = tf.get_variable(
            "W_fc1",
            shape=[num_filters_total, self._label_size],
            initializer=tf.contrib.layers.xavier_initializer())
        b_fc1 = tf.Variable(tf.constant(0.1, shape=[self._label_size]), name="b")
        l2_loss += tf.nn.l2_loss(W_fc1)
        l2_loss += tf.nn.l2_loss(b_fc1)
        y = tf.nn.xw_plus_b(h_pool_flat, W_fc1, b_fc1, name="scores")
        predictions = tf.argmax(y, 1, name="predictions")

        # CalculateMean cross-entropy loss
        losses = tf.nn.softmax_cross_entropy_with_logits(logits=y, labels=y_target)
        cross_entropy = tf.reduce_mean(losses)

        train_step = tf.train.AdamOptimizer(self._learning_rate).minimize(cross_entropy)

        # Accuracy
        correct_predictions = tf.equal(predictions, tf.argmax(y_target, 1))
        accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"), name="accuracy")
        tf.summary.scalar('acc', accuracy)

        return accuracy, x, y_target, keep_prob, train_step, y, cross_entropy, W_conv1


    def getLabelForCnn(self, dec):
        # {v:i for i,v in enumerate(list(set(dec)))} 로 한큐에 할 수 있는데 이러면 매 실행마다 라벨이 달라져서
        dic = dict()

        for d in dec:
            if dic.get(d, None) == None:
                dic[d] = len(dic)

        return dic

    def assambleData(self, enc, space_sig, token_option, tokenizer):
        enc = [tokenizer(e, token_option) for e in enc]

        enc_length = max(len(e) for e in enc)
        space_tkd = tokenizer(space_sig, token_option)

        def reassamble(e):
            e = e + space_tkd * (enc_length - len(e))
            return e

        return list(map(reassamble, enc)), enc_length

    def new_embed(self, enc, dec):
        inputs = []
        labels = []

        for e, d in zip(enc, dec):
            inputs.append(self.getEncVector(e))
            labels.append(self.getDecLabel(d))
        return inputs, labels

    def onehot_vectorize(self, bucket, x):
        import numpy as np
        np.put(bucket, self._w2v_model.wv.index2word.index(x), 1)
        return bucket

    def getEncVector(self, enc_raw):
        import numpy as np
        input = None

        if self._model_option == 'one_hot':
            bucket = np.zeros(self._w2v_dim, dtype=float).copy()
            input = np.array(list(map(
                lambda x: self.onehot_vectorize(bucket, x) if x in self._w2v_model.wv.index2word else np.zeros(self._w2v_dim,
                                                                                                dtype=float),
                enc_raw
            )))
        elif self._model_option == 'embed':
            input = np.array(list(map(
                lambda x: self._w2v_model[x] if x in self._w2v_model.wv.index2word else np.zeros(self._w2v_dim, dtype=float),
                enc_raw
            )))

        return input.flatten()

    def getDecLabel(self, dec_raw):
        # print(dec_raw)
        import numpy as np
        label = np.zeros(self._label_size, dtype=float)
        np.put(label, dec_raw, 1)
        # print(label)
        return label

    def get_kfold_data(self, fold_n):
        train_enc, train_dec, test_enc, test_dec = kfoldValidation(self._enc, self._dec, self._k_fold, fold_n)

        train_data, train_label = self.new_embed(train_enc, train_dec)  # embed(load_csv(train_data_list))
        test_data, test_label = self.new_embed(test_enc, test_dec)  # embed(load_csv(train_data_list))
        return train_label, test_label, train_data, test_data

    def run(self):
        try:
            tf.reset_default_graph()

            # Create Session
            sess = tf.Session(config=tf.ConfigProto(gpu_options=tf.GPUOptions(allow_growth=True)))

            accuracy, x, y_target, keep_prob, train_step, y, cross_entropy, W_conv1 = self.create_m_graph(train=True)

            # set saver
            saver = tf.train.Saver(tf.all_variables())
            # initialize the variables
            sess.run(tf.global_variables_initializer())

            kfolds = [self.get_kfold_data(k) for k in range(self._k_fold)]

            for i in range(self._epoch):

                for k in range(self._k_fold):
                    labels_train, labels_test, data_filter_train, data_filter_test = kfolds[k]

                    for iter, s_i in enumerate(range(0, len(data_filter_train), self._batch_size)):
                        batch_train = data_filter_train[s_i:s_i+self._batch_size]
                        batch_label = labels_train[s_i:s_i+self._batch_size]

                        if i % 10 == 0: print(
                        "epoch %d, fold %d, iter %d, train %d to %d things .." % (i, k+1, iter, s_i, s_i + len(batch_train)))
                        sess.run(train_step, feed_dict={x: batch_train, y_target: batch_label, keep_prob: 0.8})

                    #summary = sess.run(merged, feed_dict={x: data_filter_test, y_target: labels_test, keep_prob: 1})
                    #writer.add_summary(summary, global_step=i)

                    if i % 10 == 0:
                        train_accuracy = sess.run(accuracy,
                                                  feed_dict={x: data_filter_train, y_target: labels_train, keep_prob: 1})

                        print("epoch %d, training accuracy: %.3f" % (i, train_accuracy))
                        print("test accuracy: %g" % sess.run(accuracy,
                                                             feed_dict={x: data_filter_test, y_target: labels_test,
                                                                        keep_prob: 1}))


                    if i%1000==0 and i!=0:
                        checkPath(self._path)
                        saver.save(sess, self._path)
                    if train_accuracy >= 1:
                        pass#break

            # for given x, y_target data set
            print("test accuracy: %g" % sess.run(accuracy,
                                                 feed_dict={x: data_filter_test, y_target: labels_test, keep_prob: 1}))

            # Save Model
            #path = './model/'
            checkPath(self._path)
            saver.save(sess, self._path)
            print("model saved in %s"%self._path)
        except Exception as e:
            raise Exception("error on training: {0}".format(e))
        finally:
            sess.close()

class Cnn_Pred:

    def __init__(self, **kwargs):
        self._story_id = kwargs.get('story_id', 'user1/')
        self._path = model_path + self._story_id + '/'
        print(self._path)

        hps_params = loadPickle(self._path, 'hps.pkl')
        #hps_params = hps_c.getArgs()

        self._token_option = hps_params.get('token_option', 'char')
        self._encode_length = hps_params['encode_length']
        self._label_size = hps_params['label_size']
        self._learning_rate = hps_params.get('learning_rate', 1e-3)
        self._val_key = hps_params['val_key']

        self._w2v_model = kwargs.get('w2v_model', getModel(w2v_path, self._token_option))  # default w2v?
        self._model_option = kwargs.get('model_option', 'embed')
        self._w2v_dim = len(self._w2v_model.wv.index2word) if self._model_option == 'one_hot' else self._w2v_model.layer1_size
        #print('w2v',self._w2v_model)

    def create_m_graph(self, train=True):
        # placeholder is used for feeding data.
        x = tf.placeholder("float", shape=[None, self._encode_length * self._w2v_dim], name='x')
        y_target = tf.placeholder("float", shape=[None, self._label_size], name='y_target')

        # reshape input data
        x_image = tf.reshape(x, [-1, self._encode_length, self._w2v_dim, 1], name="x_image")
        # Keeping track of l2 regularization loss (optional)
        l2_loss = tf.constant(0.0)

        pooled_outputs = []
        for i, filter_size in enumerate(filter_sizes):
            with tf.name_scope("conv-maxpool-%s" % filter_size):
                # Convolution Layer
                filter_shape = [filter_size, self._w2v_dim, 1, num_filters]
                W_conv1 = tf.Variable(tf.truncated_normal(filter_shape, stddev=0.1), name="W")
                b_conv1 = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")

                conv = tf.nn.conv2d(
                    x_image,
                    W_conv1,
                    strides=[1, 1, 1, 1],
                    padding="VALID",
                    name="conv")

                # Apply nonlinearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b_conv1), name="relu")
                # Maxpooling over the outputs
                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, self._encode_length - filter_size + 1, 1, 1],
                    strides=[1, 1, 1, 1],
                    padding='VALID',
                    name="pool")
                pooled_outputs.append(pooled)

        # Combine all the pooled features
        num_filters_total = num_filters * len(filter_sizes)
        h_pool = tf.concat(pooled_outputs, 3)
        h_pool_flat = tf.reshape(h_pool, [-1, num_filters_total])

        # Add dropout
        keep_prob = 1.0
        if (train):
            keep_prob = tf.placeholder("float", name="keep_prob")
            h_pool_flat = tf.nn.dropout(h_pool_flat, keep_prob)

        # Final (unnormalized) scores and predictions
        W_fc1 = tf.get_variable(
            "W_fc1",
            shape=[num_filters_total, self._label_size],
            initializer=tf.contrib.layers.xavier_initializer())
        b_fc1 = tf.Variable(tf.constant(0.1, shape=[self._label_size]), name="b")
        l2_loss += tf.nn.l2_loss(W_fc1)
        l2_loss += tf.nn.l2_loss(b_fc1)
        y = tf.nn.xw_plus_b(h_pool_flat, W_fc1, b_fc1, name="scores")
        predictions = tf.argmax(y, 1, name="predictions")

        # CalculateMean cross-entropy loss
        losses = tf.nn.softmax_cross_entropy_with_logits(logits=y, labels=y_target)
        cross_entropy = tf.reduce_mean(losses)

        train_step = tf.train.AdamOptimizer(self._learning_rate).minimize(cross_entropy)

        # Accuracy
        correct_predictions = tf.equal(predictions, tf.argmax(y_target, 1))
        accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"), name="accuracy")
        tf.summary.scalar('acc', accuracy)

        return accuracy, x, y_target, keep_prob, train_step, y, cross_entropy, W_conv1


    def onehot_vectorize(self, bucket, x):
        import numpy as np
        np.put(bucket, self._w2v_model.wv.index2word.index(x), 1)
        return bucket

    def getPredEncVector(self, enc_raw, enc_length):
        space_tkd = tokenizer(space_sig, self._token_option)
        enc_raw = tokenizer(enc_raw, self._token_option)

        space_c = 0 if enc_length - len(enc_raw)<0 else enc_length - len(enc_raw)
        enc_raw = enc_raw[:enc_length] + space_c * space_tkd

        return self.getEncVector(enc_raw)

    def getEncVector(self, enc_raw):
        import numpy as np
        input = None

        if self._model_option == 'one_hot':
            bucket = np.zeros(self._w2v_dim, dtype=float).copy()
            input = np.array(list(map(
                lambda x: self.onehot_vectorize(bucket, x) if x in self._w2v_model.wv.index2word else np.zeros(self._w2v_dim,
                                                                                                dtype=float),
                enc_raw
            )))
        elif self._model_option == 'embed':
            input = np.array(list(map(
                lambda x: self._w2v_model[x] if x in self._w2v_model.wv.index2word else np.zeros(self._w2v_dim, dtype=float),
                enc_raw
            )))

        return input.flatten()

    def predict(self, inp):
        import os, numpy as np

        test_data = self.getPredEncVector(inp, self._encode_length)
        intent = {}

        try:
            # reset Graph
            tf.reset_default_graph()
            # Create Session
            sess = tf.Session(config=tf.ConfigProto(gpu_options=tf.GPUOptions(allow_growth=True)))
            # create graph

            _, x, _, _, _, y, _, _ = self.create_m_graph(train=False)

            # initialize the variables
            sess.run(tf.global_variables_initializer())

            # set saver
            saver = tf.train.Saver()

            # Restore Model
            # path = './model/'

            if os.path.exists(self._path):
                saver.restore(sess, self._path)  # tf.train.latest_checkpoint(model_dir)
                # print("model restored")

            # training the MLP
            # print("input data : {0}".format(test_data))
            y = sess.run([y], feed_dict={x: np.array([test_data])})
            # print('softmax :', softmax(y[0][0]))
            # print('intent :', self.__val_key[np.argmax(y)])
            sm = softmax(y[0][0])
            sm = sm[np.argmax(sm)]

            intent = {'label': self._val_key[np.argmax(y)], 'score': sm}

        except Exception as e:
            raise Exception("error on training: {0}".format(e))
        finally:
            sess.close()
            return intent

if __name__ == "__main__":
    print('[notice] you execute a default sample..')

    model_path = './models/'
    w2v_path = './default_embed/'

    story_id = 'default_user'
    enc, dec = openCsv(w2v_path,'big.txt',sep=',')
    data = makeRaw(enc, dec)

    '''
    Cnn_Train(
        story_id = unique id
        epoch = epoch
        token_option = [char | twitter]
        learning_rate = learning_rate
        k_fold = k_fold
        batch_size = batch_size
        data = data
        
        #if you have embedding model
        w2v_model=model
        model_option= [embed | one_hot]
    )
    '''
    cnn_tr = Cnn_Train(
        story_id=story_id,
        data=data
    )
    #cnn_tr.run()


    '''
    Cnn_Pred(
        story_id = unique id
        
        #if you have embedding model
        w2v_model=model
        model_option= [embed | one_hot]
    )
    '''
    cnn_pr = Cnn_Pred(
        story_id=story_id
    )

    q = '객실 예약은 어떻게 하나요?'
    i = cnn_pr.predict(q)
    print('q : %s, i : %s'%(q,i))