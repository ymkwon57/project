from konlpy.tag import Twitter#, Mecab
import jpype

t = Twitter()
#m = Mecab()

class MyError(Exception):
    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return self.msg

def getGeneratedObject(object):
    if(len(object)<=1): return object
    return (n for n in iter(object))

def openConv(data_path, file_name): # raw data 열기
    import io

    with io.open(data_path+file_name, 'r', encoding='utf-8') as f:
        # return list(map(corpusSplit, getGeneratedObject(f.read().split('\n'))))
        return f.read().split('\n')

def makeRaw(enc, dec):
    tmp = ''
    for e,d in zip(enc,dec):
        tmp += d+','+e+'\n'
    return tmp

# csv 파일 핸들러, 입력 데이터에 맞게 (인텐트,corp1,corp2, ...) 작성
def openCsv(data_path, file_name, sep):
    data = openConv(data_path, file_name)
    enc = []
    dec = []

    for d in data:
        tmp = d.split(sep)
        l = list(filter(lambda x:len(x)>0, tmp[1:]))
        enc += l
        dec += len(l)*[tmp[0]]

    return enc, dec

def getModel(path, token_option):
    from gensim.models import Doc2Vec
    model = Doc2Vec.load(path + 'default_d2v.model_'+token_option)

    return model

def checkPath(path):
    import os
    if not os.path.exists(path):
        os.makedirs(path)
        print("path created")

def getEncDec(data, sep):
    enc = []
    dec = []

    for d in data:
        tmp = d.split(sep)
        l = list(filter(lambda x:len(x)>0, tmp[1:]))
        enc += l
        dec += len(l)*[tmp[0]]

    return enc, dec

def assambleData(enc, space_sig, token_option, tokenizer):
    enc = [tokenizer(e, token_option) for e in enc]

    enc_length = max(len(e) for e in enc)  # 정사각 행렬을 위한 최대 길이
    space_tkd = tokenizer(space_sig, token_option)

    def reassamble(e):
        e = e + space_tkd * (enc_length - len(e))
        return e

    return list(map(reassamble, enc)), enc_length

def tokenizer(sentence, type):  # doc's type
    jpype.attachThreadToJVM()
    #from konlpy.tag import Twitter, Mecab

    #pos_tagger = Twitter()
    #mecab = Mecab()

    if type == 'char':
        return list(sentence)
    elif type == 'twitter':  # corpus별 사전화는 retrain 문제점 해결 후 진행
        #return ['§'.join(t) for t in pos_tagger.pos(sentence, norm=True, stem=False)]
        return t.morphs(sentence, norm=True, stem=False) # [('d','d'), ('b','b')] -> ['d/d',
    elif type == 'mecab':
        return m.morphs(sentence)

def getLabelForCnn(dec):
    # {v:i for i,v in enumerate(list(set(dec)))} 이렇게 한큐에 할 수 있는데 이러면 매 실행마다 라벨이 달라져서
    # 프레딕트에 엉뚱한 라벨이 나오는걸 방지
    dic = dict()

    for d in dec:
        if dic.get(d, None) == None:
            dic[d]=len(dic)

    return dic

def kfoldValidation(enc, dec, k_fold, fold_n):
    #train_enc, train_dec, test_enc, test_dec = [], [], [], []

    fold_range = int(len(dec)/k_fold) # round down

    # 5 fold -> fold 0, 1, 2, 3, 4
    s_i = fold_n * fold_range
    e_i = len(dec) if fold_n==k_fold-1 else (fold_n*fold_range) + fold_range
    tr_e = enc[0:s_i]+enc[e_i:]
    tr_d = dec[0:s_i]+dec[e_i:]
    ts_e = enc[s_i:e_i]
    ts_d = dec[s_i:e_i]

    return tr_e, tr_d, ts_e, ts_d

def testValidation(enc, dec, train=8):
    if (train >= 10):
        print('train이 10을 초과하여 기본값인 8로 수행합니다')
        train = 8

    train_enc, train_dec, test_enc, test_dec = [], [], [], []
    indexes = getIndexes(dec)  # [0, 12 ... ]
    #print(indexes)

    for i in range(len(indexes)-1):
        s_i = indexes[i]
        e_i = indexes[i + 1]
        tr_e, tr_d, ts_e, ts_d = dataShuffle(enc[s_i:e_i], dec[s_i:e_i], s_i, e_i, train / 10)
        train_enc += tr_e;
        train_dec += tr_d;
        test_enc += ts_e;
        test_dec += ts_d
        #print(tr_e, tr_d)
        #print(ts_e, ts_d)

    return train_enc, train_dec, test_enc, test_dec


def dataShuffle(enc, dec, s_i, e_i, per):
    import random
    #from random import shuffle
    from copy import deepcopy

    i = random.randint(1,100)

    mid = round((e_i - s_i) * per)

    enc = deepcopy(enc)
    dec = deepcopy(dec)
    random.seed(i)
    random.shuffle(enc)
    random.seed(i)
    random.shuffle(dec)

    tr_e = enc[:mid]; tr_d = dec[:mid]; ts_e = enc[mid:]; ts_d = dec[mid:]
    #print(tr_d, ts_d)
    return tr_e, tr_d, ts_e, ts_d

def makePath(path):
    import os
    if not os.path.exists(path):
        os.makedirs(path)
        print("path created")

def savePickle(path,name,param):
    import pickle

    makePath(path)
    with open(path+name, 'wb') as mysavedata:
        pickle.dump(param, mysavedata)

def loadPickle(path,name):
    import pickle

    with open(path+name,'rb') as myloaddata:
        return pickle.load(myloaddata)


def getIndexes(dec):
    label = ''
    indexes = []
    for i, d in enumerate(dec):
        if label != d:
            indexes.append(i)
            label = d
    indexes += [len(dec)] if indexes[-1] != len(dec) else []

    return indexes

def softmax(a):
    import numpy as np
    c = np.max(a)
    exp_a = np.exp(a-c)
    sum_exp_a = np.sum(exp_a)
    y = exp_a / sum_exp_a

    return y