from dslib import tokenizer

space_sig = '➣'
start_sig = '▹'
end_sig = '▿'

def getModel(dict_path, token_option, w2v_epoch):
    from gensim.models import Doc2Vec
    model = Doc2Vec.load(dict_path + 'doc2vec.model_' + token_option + '_' + str(w2v_epoch))

    return model

class Word2Vec:
    # options
    __token_option = None
    __dict_path = None

    # hparams
    __w2v_window = None
    __w2v_size = None
    __w2v_epoch = None


    def __init__(self, token_option, dict_path, w2v_window, w2v_size, w2v_epoch):
        self.setOptions(token_option, dict_path)
        self.setHyperPrams(w2v_window,w2v_size,w2v_epoch)

    def setOptions(self, token_option, dict_path):
        self.__token_option = token_option
        self.__dict_path = dict_path

    def setHyperPrams(self, w2v_window, w2v_size, w2v_epoch):
        self.__w2v_window = w2v_window; self.__w2v_size = w2v_size; self.__w2v_epoch=w2v_epoch

    def getWord2Vec(self, sentences, max_sentence_len):
        import os
        from gensim.models import Doc2Vec

        if not os.path.exists(self.__dict_path):
            os.makedirs(self.__dict_path)
            print("path created")

        print(u'check w2v model .. ', end='')
        if (not os.path.exists(self.__dict_path + 'doc2vec.model_' + self.__token_option + '_' + str(self.__w2v_epoch))):
            self.makeWord2Vec(sentences)

        print(u'\nload w2v model .. ', end='')
        model = Doc2Vec.load(self.__dict_path + 'doc2vec.model_' + self.__token_option + '_' + str(self.__w2v_epoch))
        print(u'[OK]')

        return model

    def makeWord2Vec(self, sentences):
        from gensim.models import Doc2Vec
        from collections import namedtuple
        TaggedDocument = namedtuple('TaggedDocument', 'words tags')

        print(u'\nmake w2v model ..')

        sentences = [(s, 1) for s in sentences]  # [(['안','녕', ... ], taggedDoc), ... ]
        tagged_train_docs = [TaggedDocument(d, [c]) for d, c in sentences]
        del (sentences)

        doc_vectorizer = Doc2Vec(dm=1, window=self.__w2v_window, size=self.__w2v_size, alpha=0.025, min_alpha=0.025, seed=9999,
                                 min_count=1)
        doc_vectorizer.build_vocab(tagged_train_docs)

        for epoch in range(self.__w2v_epoch):
            print('w2v epoch :', epoch+1, '/', self.__w2v_epoch)
            doc_vectorizer.train(tagged_train_docs, total_words=None, word_count=0,
                                 total_examples=doc_vectorizer.corpus_count, queue_factor=2, report_delay=1.0,
                                 epochs=doc_vectorizer.iter)

            doc_vectorizer.alpha -= 0.0002  # decrease the learning rate
            doc_vectorizer.min_alpha = doc_vectorizer.alpha
        doc_vectorizer.wv.index2word
        doc_vectorizer.docvecs.offset2doctag

        doc_vectorizer.save(self.__dict_path + 'doc2vec.model_' + self.__token_option + '_' + str(self.__w2v_epoch))
        print(u'[Training Complete]');


class OneHot:

    __token_option = None
    __dict_path = None

    def __init__(self, token_option, dict_path):
        self.setOptions(token_option, dict_path)

    def setOptions(self, token_option, dict_path):
        self.__token_option = token_option
        self.__dict_path = dict_path

    def getOne_hot(self, sentences, max_sentence_len):
        import os, pickle


        print(u'check one_hot pickle .. ', end='')
        path = '{folder}one_hot_{token_option}_{len}'.format(folder=self.__dict_path,token_option=self.__token_option,
                                                             len=str(max_sentence_len))
        if (not os.path.exists(path)):
            self.makeOne_hot(sentences, max_sentence_len)

        print(u'\nload one_hot dic .. ', end='')
        with open(path, 'rb') as myloaddata:
            print(u'[OK]')
            return pickle.load(myloaddata)

    def makeOne_hot(self, sentences, max_sentence_len):
        import pickle
        from current_lib.dslib import getGeneratedObject

        print('make one_hot dic .. ', end='')
        path = '{folder}one_hot_{token_option}_{len}'.format(folder=self.__dict_path, token_option=self.__token_option,
                                                             len=str(max_sentence_len))
        s = set()


        for sentence in getGeneratedObject(sentences):
            for token in sentence:
                s.add(token)

        del(sentences)


        s -= set(tokenizer(start_sig, self.__token_option))
        s -= set(tokenizer(end_sig, self.__token_option))
        s -= set(tokenizer(space_sig, self.__token_option))
        s = list(s) + [tokenizer(start_sig, self.__token_option)[0], tokenizer(end_sig, self.__token_option)[0], tokenizer(space_sig, self.__token_option)[0]]

        s = {n: i for i, n in enumerate(getGeneratedObject(s))}

        print('inner :',s)

        with open(path, 'wb') as mysavedata:
            pickle.dump(s, mysavedata)
        print('[OK]')