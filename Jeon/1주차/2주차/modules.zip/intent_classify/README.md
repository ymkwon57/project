# Data Driven Dialogue System
## Intent Classifier (Char-CNN)
### env
    * Python 3.6.1
    * Tensorflow 1.4.0 (OSX)
    * Gensim 3.0.0
    * (optional) Konlpy 0.4.4

### current lib
    * /modules/intent_classify/dslib.py

## How to use
### 1.Training
    from Cnn import Cnn_Train

    cnn_tr = Cnn_Train(
        params ...
    )

    cnn_tr.run()

______________________________
### Params
    Cnn_Train(
        story_id = unique id
        epoch = epoch
        token_option = [char | twitter]
        learning_rate = learning_rate
        k_fold = k_fold
        batch_size = batch_size
        **data = data**

        #if you have embedding model
        w2v_model=model
        model_option= [embed | one_hot]
    )

______________________________
### Data
    data = 'label,example\nlabel,example\n ... '

    if you have 'enc = [example1, example2 ... ]', 'dec = [label1, label2 ... ]'
    use 'makeRaw(enc, dec)' in dslib.py

______________________________
### 2.Predict
    from Cnn import Cnn_Pred

    cnn_pr = Cnn_Pred(
        params ...
    )

    intent = cnn_pr.predict(user_input_data)

______________________________
### Params
    Cnn_Pred(
        story_id = unique id

        #if you have embedding model
        w2v_model=model
        model_option= [embed | one_hot]
    )